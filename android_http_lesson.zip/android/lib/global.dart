import 'article.dart';

String imgLink;
List<Article> myArticleList = [
  Article.dress1(),
  Article.dress2(),
  Article.dress3(),
  Article.dress4(),
  Article.dress5(),
  Article.dress6(),
  Article.dress7(),
  Article.dress8(),
];
